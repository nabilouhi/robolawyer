// $("input[name='concernYou']").change(function() {
//   result = this.value;

//   if (result === 'No') {
//     $('.concernOther').removeClass('is-hidden');
//   } else if (result === 'Yes') {
//     $('.concernOther').addClass('is-hidden');
//   }
// });
